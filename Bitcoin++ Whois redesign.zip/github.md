repo: btcppdev/website
branch: master

## Last sync
date: 2026-08-17T23:17:06Z

### Updated in this project
- Read whois.tmpl, whois_profile.tmpl, and whois CSS from static/css/btcpp-redesign.css
- Built contained-layout redesign variants for /whois and /whois/{speaker}
- Final direction: 2a "framed dossier" (1240px ruled frame), full profile + index build-out
- Merged sections from prior design (Profile.html): volunteer star callout, +N badges tile, awards podium, technical writing, credentials, richer hero

## Screen map
| Screen | Repo files |
|---|---|
| whois Redesign.dc.html (profile variants) | templates/whois_profile.tmpl, static/css/btcpp-redesign.css |
| whois Redesign.dc.html (index variants) | templates/whois.tmpl, static/css/btcpp-redesign.css |
